package arrays;

public class asList {

}
